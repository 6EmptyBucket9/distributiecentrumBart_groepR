class Config:
    SECRET_KEY = 'your_secret_key'
    SQLALCHEMY_DATABASE_URI = 'mysql+pymysql://root:R00twachtwoord!@localhost:3307/dbart'
    SQLALCHEMY_TRACK_MODIFICATIONS = False
